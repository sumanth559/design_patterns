package Creational.Bridge_Pattern;
public interface DrawAPI {
	public void drawCircle(int radius, int x, int y);
}